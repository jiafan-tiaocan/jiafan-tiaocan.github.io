# OKF：零售净收入可运行教学案例

这是为 OKF 解读文章制作的小型演示。全部业务口径、订单、退款和人工复核身份均为教学设定；不是 Google 官方样例，不代表真实经营数据或实际人工签字。

2026 年 9 月线上渠道有三条订单：100 元 paid、200 元 paid、50 元 cancelled；一条已确认退款为 20 元。因此按本例固定口径，净收入是 **280 元** 。

## 运行

只需 Python 3.9 或更高版本的标准库；不安装依赖、不联网、不使用数据库。在解压后的目录运行：

```bash
python3 run_demo.py
```

程序执行全部教学场景，打印 JSON，并保存到 `demo-results.json`。可选月份与渠道参数：

```bash
python3 run_demo.py --month 2026-09 --channel store
python3 run_demo.py --month 2026-08 --channel online
```

这两种参数在当前输入中均返回 0；默认 `2026-09` / `online` 返回 280。输出的 `requested_run` 是指定参数的运行结果，`cases` 始终重现固定教学场景。`channel` 也可以是 `all`。不开放修改算法的参数。

为保证未来仍能重现时间判断，消费时点固定为 `2026-09-08T12:00:00+08:00`；`executed_at` 则记录真实运行时间。

## 文件怎样分工

```text
bundle/                           ← OKF 知识包；可单独分发
  index.md                        ← 渐进发现入口
  log.md                          ← 日期分组变更记录
  metrics/net-revenue.md           ← 净收入含义，链接到计算概念
  computations/net-revenue.md      ← 参数、计算、executor、attester 契约
  policies/revenue-recognition.md ← 虚构业务口径
  tables/orders.md                ← 订单字段与渠道、月份语义
  tables/refunds.md               ← 退款字段、关联与退款月份语义
  references/demo-data.md          ← 解释教学输入，脚注关联 sources
  references/net_revenue.py        ← 被批准的固定算法
  references/executor.py           ← 执行并生成 receipt
  references/attester.py           ← 确定性检查单次运行
  references/runtime_support.py    ← 本地解析和消费策略
  references/data/*.json          ← 三条订单与一条退款
source-lock.json                  ← 教学用批准代码与数据 SHA 快照
runtime/run-records/              ← bundle 外的本地运行记录
runtime/*-receipt.json            ← 两个可直接查看的 receipt
run_demo.py                       ← 消费者、场景与断言
demo-results.json                 ← 实际运行结果
```

为避免引入第三方 YAML 解析器，本包 frontmatter 使用 **JSON 对象形式的 YAML** 。它是有效 YAML；`read_frontmatter` 只解析本包使用的这一子集，不能充当通用 OKF/YAML 解析器。文章中的普通 YAML 写法与它表达同一份契约。

## 一次运行做了什么

1. 消费者发现指标，跟随 Markdown 链接加载独立计算概念，只填月份与渠道。
2. executor 读取计算文件快照，在独立 Python 子进程执行这些确切字节，并把绑定参数和数据传入。返回的 receipt 包含 `run_id`、执行代码 SHA、输入 SHA、数据 SHA、参数和结果。
3. attester 按 `run_id` 重读本地运行记录，把代码 SHA 与 `source-lock.json` 中的批准 SHA 比较，再核对参数与输入，并使用批准算法重算结果。最后比较页面准备展示的值与运行记录中的值。
4. 本地消费策略分别处理定义是否过期、是否有当前内容的复核。演示报告只有在单次检查通过且策略允许时才自动采用数值。

数据 SHA 在本例用于固定教学输入；真实系统中的动态数据版本、可重现快照和查询任务记录需要另外设计。

## 实际结果

随包保存的 `demo-results.json` 已实际执行，51 项断言通过。关键结果如下：

| 场景 | 运行值 / 展示值 | 单次检查 | 本地自动报表 |
|---|---|---|---|
| 正常 | 280 / 280 | 通过 | 采用 |
| 擅自把 cancelled 计入 | 330 / 330 | 代码 SHA、重算结果不符 | 不采用 |
| 只改展示值 | 280 / 300 | 展示值不符 | 不采用 |
| 改 receipt 中的值 | 运行记录 280，伪造为 999 | receipt 与运行记录不符 | 不采用 |
| 以线上运行冒充门店参数 | 原运行 280，门店应为 0 | 参数、绑定输入、结果不符 | 不采用 |
| 恰好到 `stale_after` | 280 / 280 | 通过，定义已过期 | 不采用 |
| 人工复核早于内容生成 | 280 / 280 | 通过，旧复核不覆盖新内容 | 不采用 |

“运行通过但定义过期”是有意保留的结果：它说明 `verified` / `stale_after` 与单次 attestation 解决不同问题。

## 哪些来自规范，哪些属于本例

依据是新仓库 [GoogleCloudPlatform/open-knowledge-format 的 SPEC.md](https://github.com/GoogleCloudPlatform/open-knowledge-format/blob/ad30107c31c06aec8a7d5636e0d1058118604e6f/SPEC.md)，核验于 2026-09-08。锁定提交 `ad30107c31c06aec8a7d5636e0d1058118604e6f`，提交时间为 2026-08-21；该规范仍声明版本 `0.2`。

规范约定包括：概念以 `type` 标识；脚注 label 对应 `sources[].id`；独立 `Attested Computation` 的 `runtime`、`parameters`、`computation`、`executor`、`attester`；receipt 是运行时产物；attester 为确定性代码；时间戳必须带 UTC 偏移。

规范信任等级单独保存在 `spec_trust_tier`：没有 `verified` 为 `unverified`，只有非 `human:` 复核者为 `machine-confirmed`，含 `human:` 复核者为 `human-reviewed`。一个 `{by, at}` 映射与单元素列表同义。`now >= stale_after` 才是过期判断。

以下是 **本例的消费策略** ，不能说成 OKF 强制规则：

- 只有 `generated.at <= verified.at <= now` 的复核才覆盖当前内容；旧人工复核仍产生规范上的 `human-reviewed`，同时本例的 `local_current_review` 为 false。
- 未复核、过期、非 stable 的知识仍可读取，但本例不把它直接用于自动报表。
- 人工复核场景只在内存中模拟，不会往 bundle 写入虚假的实际人工签字。
- `verified` 的空列表按未复核处理，是本解析器的防御性约定。

`stdin/stdout` JSON、receipt 字段名、函数签名、verdict 格式、代码锁、数据哈希和自动报表准入都是 **本例实现约定** 。规范 §12 明确把完整运行协议、receipt/verdict 线格式以及 attester ABI、可移植性与沙箱留待后续；本包不宣称实现了官方统一运行协议。代码中的结构检查只验证这个教学包，不能代替完整通用合规验证器。

## 这个演示能证明到哪里

它能重现“算错口径”“改展示值”“参数对不上”“旧定义仍能算出数值”如何被不同检查发现。

executor、运行记录、SHA 锁和 attester 都位于同一本地信任域。拥有全部写权限的人可以一起改写这些文件；SHA 本身不能证明远程计算确实发生，也不能证明输入数据和业务口径为真。这里重读的是模拟的本地权威记录，不能替代真实环境中由独立可信系统提供的任务身份、执行产物、结果回读与审计记录。生产方案还需落实信任边界与代码执行隔离。
