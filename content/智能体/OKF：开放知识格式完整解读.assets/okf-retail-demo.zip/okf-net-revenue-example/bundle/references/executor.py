"""Teaching executor. Receipts and records are runtime artifacts outside bundle."""
import json
import uuid
from runtime_support import canonical, run_python, sha256, source_and_payload


def execute(root, parameters, computation_override=None):
    approved_source, payload, data_hashes = source_and_payload(root, parameters)
    source = approved_source if computation_override is None else computation_override
    result = run_python(source, payload)
    receipt = {
        "run_id": uuid.uuid4().hex,
        "executed_file_sha256": sha256(source),
        "input_sha256": sha256(canonical(payload)),
        "data_sha256": data_hashes,
        "parameters": dict(parameters),
        "result": result,
    }
    records = root / "runtime" / "run-records"
    records.mkdir(parents=True, exist_ok=True)
    (records / (receipt["run_id"] + ".json")).write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return receipt
