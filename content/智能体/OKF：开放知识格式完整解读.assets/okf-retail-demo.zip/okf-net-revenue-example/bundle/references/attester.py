"""Deterministic teaching attester, not an official OKF ABI or remote proof."""
import json
import re
from runtime_support import canonical, run_python, sha256, source_and_payload


def attest(root, requested_parameters, receipt, displayed_value):
    reasons = []
    run_id = receipt.get("run_id", "")
    if not re.fullmatch(r"[a-f0-9]{32}", run_id):
        return {"passed": False, "reasons": ["invalid_run_id"]}
    record_path = root / "runtime" / "run-records" / (run_id + ".json")
    try:
        record = json.loads(record_path.read_text(encoding="utf-8"))
        approved_source, payload, data_hashes = source_and_payload(root, requested_parameters)
        lock = json.loads((root / "source-lock.json").read_text(encoding="utf-8"))
    except (OSError, ValueError, KeyError) as exc:
        return {"passed": False, "reasons": ["unreadable_evidence"],
                "detail": str(exc)}
    if sha256(approved_source) != lock["approved_computation_sha256"]:
        reasons.append("sanctioned_file_changed")
    if data_hashes != lock["data_sha256"]:
        reasons.append("fixture_data_changed")
    if receipt != record:
        reasons.append("receipt_differs_from_run_record")
    if record.get("executed_file_sha256") != lock["approved_computation_sha256"]:
        reasons.append("executed_file_hash_mismatch")
    if record.get("parameters") != requested_parameters:
        reasons.append("parameters_mismatch")
    if record.get("input_sha256") != sha256(canonical(payload)):
        reasons.append("input_binding_mismatch")
    if record.get("data_sha256") != data_hashes:
        reasons.append("input_data_hash_mismatch")
    # Recompute only the locally sanctioned, digest-pinned file, never receipt code.
    if "sanctioned_file_changed" not in reasons and "fixture_data_changed" not in reasons:
        expected_result = run_python(approved_source, payload)
        if record.get("result") != expected_result:
            reasons.append("result_mismatch")
    if displayed_value != record.get("result", {}).get("net_revenue_yuan"):
        reasons.append("displayed_value_mismatch")
    return {"passed": not reasons, "reasons": reasons,
            "evidence_scope": "local_same_trust_domain_demo"}
