"""Only this example's JSON-compatible YAML subset is supported."""
import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def sha256(value):
    return hashlib.sha256(value).hexdigest()


def read_frontmatter(path):
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        raise ValueError("missing frontmatter: " + str(path))
    metadata, body = text[4:].split("\n---\n", 1)
    return json.loads(metadata), body


def validate_parameters(contract, parameters):
    # OKF declares the surface; these Python types/domain checks are local.
    declared = {item["name"] for item in contract["parameters"]}
    if set(parameters) != declared:
        raise ValueError("only month and channel may be supplied")
    for item in contract["parameters"]:
        if item["type"] != "string" or not isinstance(parameters[item["name"]], str):
            raise ValueError("this example expects string parameters")
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", parameters["month"]):
        raise ValueError("month must use YYYY-MM")
    if parameters["channel"] not in {"online", "store", "all"}:
        raise ValueError("channel must be online, store, or all")


def source_and_payload(root, parameters):
    bundle = root / "bundle"
    contract, _ = read_frontmatter(bundle / "computations/net-revenue.md")
    validate_parameters(contract, parameters)
    source = (bundle / contract["computation"].lstrip("/")).read_bytes()
    orders = (bundle / "references/data/orders.json").read_bytes()
    refunds = (bundle / "references/data/refunds.json").read_bytes()
    payload = {"parameters": parameters,
               "orders": json.loads(orders), "refunds": json.loads(refunds)}
    data_hashes = {"orders.json": sha256(orders), "refunds.json": sha256(refunds)}
    return source, payload, data_hashes


def run_python(source, payload):
    # Execute precisely the bytes whose digest is recorded, passing data as JSON.
    # The example runner only executes locally authored fixture code.
    proc = subprocess.run([sys.executable, "-B", "-c", source.decode("utf-8")],
                          input=canonical(payload), capture_output=True,
                          timeout=5, check=True)
    return json.loads(proc.stdout)


def aware_time(value):
    moment = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if moment.tzinfo is None or moment.utcoffset() is None:
        raise ValueError("timestamp must have an explicit UTC offset")
    return moment.astimezone(timezone.utc)


def trust_tier(metadata):
    events = metadata.get("verified", [])
    if isinstance(events, dict):
        events = [events]
    if not events:
        return "unverified"
    return ("human-reviewed" if any(event["by"].startswith("human:")
                                    for event in events)
            else "machine-confirmed")


def consumption_policy(metadata, now):
    """Separate spec signals from this example's stricter operational policy."""
    now = aware_time(now)
    events = metadata.get("verified", [])
    if isinstance(events, dict):
        events = [events]
    generated = metadata.get("generated", {}).get("at")
    valid_reviews = [event for event in events
                     if (generated is None or
                         aware_time(event["at"]) >= aware_time(generated))
                     and aware_time(event["at"]) <= now]
    stale = ("stale_after" in metadata
             and now >= aware_time(metadata["stale_after"]))
    status = metadata.get("status", "stable")
    reasons = []
    if stale:
        reasons.append("definition_expired")
    if not valid_reviews:
        reasons.append("no_current_review")
    if status != "stable":
        reasons.append("definition_not_stable")
    return {"spec_trust_tier": trust_tier(metadata),
            "spec_status": status, "spec_stale": stale,
            "local_current_review": bool(valid_reviews),
            "local_use_for_automatic_report": not reasons,
            "local_reasons": reasons,
            "readable_as_knowledge": True}
