---
{
  "type": "Reference",
  "title": "虚构订单与退款数据",
  "description": "三条订单和一条退款，全属人工构造的教学输入。",
  "generated": {
    "by": "okf-teaching-example/1.0",
    "at": "2026-09-07T08:00:00+08:00"
  },
  "sources": [
    {
      "id": "orders-fixture",
      "resource": "/references/data/orders.json",
      "title": "订单 JSON 教学数据"
    },
    {
      "id": "refunds-fixture",
      "resource": "/references/data/refunds.json",
      "title": "退款 JSON 教学数据"
    }
  ]
}
---
# 输入

以下订单均在 `2026-09`、`online` 渠道。[^orders-fixture]

| 订单 | 状态 | 金额（元） |
|---|---|---:|
| O-001 | paid | 100 |
| O-002 | paid | 200 |
| O-003 | cancelled | 50 |

退款 R-001 对应 O-001，退款月份为 `2026-09`，状态为 `confirmed`，金额为 20 元。[^refunds-fixture]

因此固定口径结果为 280 元。若把 cancelled 订单计入，会错误得到 330 元；若展示者省略退款，会错误展示 300 元。这两类错误需要不同检查。

[^orders-fixture]: orders.json
[^refunds-fixture]: refunds.json

逐项字段说明见[订单](/tables/orders.md)与[退款](/tables/refunds.md)；口径以[收入确认政策](/policies/revenue-recognition.md)为准。
