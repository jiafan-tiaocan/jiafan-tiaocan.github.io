"""教学用固定算法：按月份与渠道计算整数人民币净收入。

stdin/stdout JSON 是本教学包的调用约定，并非 OKF 官方 ABI。
本文件只依赖 Python 标准库；不联网，不使用数据库。
"""
import json
import sys


def calculate(orders, refunds, month, channel):
    def in_channel(order):
        return channel == "all" or order["channel"] == channel

    paid_orders = {order["id"]: order for order in orders
                   if order["status"] == "paid"}
    sales = sum(order["amount_yuan"] for order in paid_orders.values()
                if order["month"] == month and in_channel(order))
    returns = sum(refund["amount_yuan"] for refund in refunds
                  if refund["status"] == "confirmed"
                  and refund["month"] == month
                  and refund["order_id"] in paid_orders
                  and in_channel(paid_orders[refund["order_id"]]))
    return {"currency": "CNY", "sales_yuan": sales,
            "refunds_yuan": returns, "net_revenue_yuan": sales - returns}


if __name__ == "__main__":
    payload = json.load(sys.stdin)
    result = calculate(payload["orders"], payload["refunds"],
                       **payload["parameters"])
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
