---
{
  "type": "Table",
  "title": "退款教学输入",
  "description": "教学退款 JSON 的逐项字段、订单关联和按退款月归属规则。",
  "resource": "/references/data/refunds.json",
  "generated": {
    "by": "okf-teaching-example/1.0",
    "at": "2026-09-07T08:00:00+08:00"
  },
  "sources": [
    {
      "id": "refunds-fixture",
      "resource": "/references/data/refunds.json",
      "title": "退款 JSON 教学数据"
    }
  ]
}
---
# Schema

本概念描述代码实际读取的虚构 JSON 输入，不连接数据库；每条记录对应一笔退款。[^refunds-fixture]

| 字段 | 类型 | 含义与本例约束 |
|---|---|---|
| `id` | string | 退款标识，例如 `R-001`。 |
| `order_id` | string | 对应[订单](/tables/orders.md)的 `id`。 |
| `month` | string | 退款归属月份，格式 `YYYY-MM`；并非订单月份。 |
| `status` | string | 退款状态；本包唯一退款为 `confirmed`。 |
| `amount_yuan` | integer | 退款金额，人民币元。 |

# 关联与归属

[净收入计算](/computations/net-revenue.md)只扣除状态为 `confirmed`、退款 `month` 等于所选月份，且 `order_id` 关联到 `paid` 订单的退款。

退款输入没有 `channel` 字段；渠道取关联订单的 `channel`。退款可以关联更早月份的 paid 订单：本月扣减仍按退款自身月份处理，不要求订单也在本月。`channel=all` 表示不限制渠道。完整规则见[政策](/policies/revenue-recognition.md)。

本包退款 R-001 关联 O-001，退款月份为 `2026-09`，金额 20 元。

[^refunds-fixture]: refunds.json 中的实际教学输入字段
