---
{
  "type": "Table",
  "title": "订单教学输入",
  "description": "教学订单 JSON 的逐项字段和业务语义。",
  "resource": "/references/data/orders.json",
  "generated": {
    "by": "okf-teaching-example/1.0",
    "at": "2026-09-07T08:00:00+08:00"
  },
  "sources": [
    {
      "id": "orders-fixture",
      "resource": "/references/data/orders.json",
      "title": "订单 JSON 教学数据"
    }
  ]
}
---
# Schema

本概念描述代码实际读取的虚构 JSON 输入，不连接数据库；每条记录对应一个订单。[^orders-fixture]

| 字段 | 类型 | 含义与本例约束 |
|---|---|---|
| `id` | string | 订单标识，例如 `O-001`；本例唯一。 |
| `month` | string | 订单归属月份，格式 `YYYY-MM`。 |
| `channel` | string | 订单渠道；本包三条输入均为 `online`。 |
| `status` | string | 支付状态；输入含 `paid` 与 `cancelled`。 |
| `amount_yuan` | integer | 订单金额，人民币元。 |

# 计算关系

[净收入计算](/computations/net-revenue.md)只将 `paid` 订单计入收入，按订单 `month` 和所选 `channel` 过滤；`cancelled` 的 50 元不计入。`channel=all` 表示不限制渠道。

[退款](/tables/refunds.md)以 `order_id` 关联本表 `id`，并取订单的渠道。退款按退款自身月份计入，所以允许关联发生在更早月份的 paid 订单；收入与退款的月份条件分别判断。完整口径见[政策](/policies/revenue-recognition.md)。

[^orders-fixture]: orders.json 中的实际教学输入字段
