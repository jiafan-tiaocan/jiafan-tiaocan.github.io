---
{
  "type": "Reference",
  "title": "虚构零售净收入口径",
  "description": "用于本教学包的明确算法边界。",
  "generated": {
    "by": "okf-teaching-example/1.0",
    "at": "2026-09-07T08:00:00+08:00"
  }
}
---
# 教学口径

收入部分：订单状态为 `paid`，按订单月份计入，按订单渠道过滤。

退款部分：退款状态为 `confirmed`，按退款月份计入；仅处理关联 `paid` 订单的退款，渠道取关联订单。允许退款对应的订单发生在更早月份。

净收入 = 收入部分 − 退款部分。`cancelled` 订单不计入。`channel=all` 表示全部渠道。

数据使用整数人民币元。税费、汇率、部分支付、异常退款、跨主体对账与正式会计收入确认均未建模。这是一项刻意缩小的教学定义。

字段与关联见[订单](/tables/orders.md)和[退款](/tables/refunds.md)；此政策由[净收入计算](/computations/net-revenue.md)实现。
