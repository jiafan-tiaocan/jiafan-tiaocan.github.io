# 口径

* [净收入确认口径](revenue-recognition.md) - 虚构零售的收入、退款与归属边界。
