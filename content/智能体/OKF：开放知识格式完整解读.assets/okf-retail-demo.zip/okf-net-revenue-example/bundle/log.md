# 知识包变更记录

## 2026-09-08

* **创建** 本教学包，新增[指标](/metrics/net-revenue.md)、[计算](/computations/net-revenue.md)与两个来源概念。
* **验证** 使用标准库脚本检查正常、篡改、过期与旧复核场景；实际结果位于知识包外的 `demo-results.json`。
* **整理** 将虚构政策归入 `policies/revenue-recognition.md`，新增[订单](/tables/orders.md)与[退款](/tables/refunds.md)概念；统一阅读路径与实际代码输入。
