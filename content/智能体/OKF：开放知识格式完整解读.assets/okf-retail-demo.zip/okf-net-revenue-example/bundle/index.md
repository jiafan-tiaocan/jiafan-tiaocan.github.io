---
{"okf_version": "0.2"}
---
# 零售净收入教学知识包

* [净收入含义](metrics/net-revenue.md) - 通过三条订单和一条退款理解口径、来源与单次运行检查。
* [净收入计算](computations/net-revenue.md) - 固定算法，开放月份与渠道参数。
* [教学口径](policies/revenue-recognition.md) - 定义收入、退款与渠道范围。
* [教学数据](references/demo-data.md) - 三条订单和一条退款。
* [订单字段](tables/orders.md) - 订单金额、状态、月份与渠道。
* [退款字段](tables/refunds.md) - 退款金额、状态、关联和归属月份。
