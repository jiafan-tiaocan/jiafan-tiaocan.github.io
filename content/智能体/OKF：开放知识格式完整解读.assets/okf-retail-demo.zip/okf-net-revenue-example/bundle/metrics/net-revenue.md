---
{
  "type": "Metric",
  "title": "零售净收入（教学）",
  "description": "通过三条订单和一条退款理解口径、来源与单次运行检查。",
  "generated": {
    "by": "okf-teaching-example/1.0",
    "at": "2026-09-07T08:00:00+08:00"
  },
  "status": "stable",
  "tags": [
    "teaching",
    "retail",
    "revenue"
  ],
  "sources": [
    {
      "id": "revenue-policy",
      "resource": "/policies/revenue-recognition.md",
      "title": "虚构零售净收入口径"
    }
  ]
}
---
# 业务问题

“2026 年 9 月线上渠道的净收入是多少？”本例采用 paid 订单减 confirmed 退款的教学口径。[^revenue-policy]

本页说明含义；实际计算使用独立的[净收入计算概念](/computations/net-revenue.md)。定义的复核、新鲜度和每次运行的检查应分别读取与判断，不能从一个叙述页面自动继承到所有数值。

所有公司、数据和业务口径均为教学设定，不能当作会计或真实经营结论。

[^revenue-policy]: 虚构零售净收入口径
