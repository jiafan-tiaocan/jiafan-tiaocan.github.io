---
{
  "type": "Attested Computation",
  "title": "按月份和渠道计算净收入（教学）",
  "description": "固定计算 paid 订单金额减 confirmed 退款；只开放月份与渠道参数。",
  "runtime": "python",
  "parameters": [
    {
      "name": "month",
      "type": "string",
      "required": true
    },
    {
      "name": "channel",
      "type": "string",
      "required": true
    }
  ],
  "computation": "/references/net_revenue.py",
  "executor": {
    "resource": "/references/executor.py",
    "receipt": [
      "run_id",
      "executed_file_sha256",
      "input_sha256",
      "data_sha256",
      "parameters",
      "result"
    ]
  },
  "attester": {
    "resource": "/references/attester.py"
  },
  "generated": {
    "by": "okf-teaching-example/1.0",
    "at": "2026-09-07T08:00:00+08:00"
  },
  "verified": {
    "by": "process:teaching-fixture-check",
    "at": "2026-09-08T09:00:00+08:00"
  },
  "status": "stable",
  "stale_after": "2026-09-09T00:00:00+08:00",
  "sources": [
    {
      "id": "revenue-policy",
      "resource": "/policies/revenue-recognition.md",
      "title": "虚构零售净收入口径"
    },
    {
      "id": "demo-data",
      "resource": "/references/demo-data.md",
      "title": "虚构订单与退款数据"
    }
  ]
}
---
# Computation

批准算法放在 `computation` 指向的 Python 文件中；此正文不重复内联另一份算法。只允许传入 `month` 与 `channel`，不允许改写计算口径。金额是整数人民币元。

月份形式为 `YYYY-MM`；渠道可为 `online`、`store` 或 `all`。这些参数域和 Python 的 stdin/stdout JSON 调用方式是本例约定，不是 OKF 统一 ABI。

本例净收入等于本月该渠道的 paid 订单金额，减本月 confirmed 且关联 paid 订单的退款金额。退款按退款月份计入，渠道取关联订单。[^revenue-policy]

`2026-09`、`online` 的结果为 `100 + 200 − 20 = 280`；cancelled 的 50 元不计入。[^demo-data]

`generated` 与 `verified` 使用固定教学时间，`process:teaching-fixture-check` 仅代表本包自动测试对虚构口径与数据的检查；不代表真实业务审批或人工签字。运行时的 receipt 与 verdict 放在 bundle 外。

[^revenue-policy]: 虚构零售净收入口径
[^demo-data]: 本包三条订单和一条退款
