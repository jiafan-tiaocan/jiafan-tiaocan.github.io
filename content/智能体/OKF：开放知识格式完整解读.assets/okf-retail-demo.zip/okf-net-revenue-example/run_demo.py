#!/usr/bin/env python3
"""Run an executable, fictional OKF teaching case with Python's standard library."""
import argparse
import copy
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "bundle/references"))
from attester import attest
from executor import execute
from runtime_support import (aware_time, consumption_policy, read_frontmatter,
                             trust_tier, validate_parameters)

NOW = "2026-09-08T12:00:00+08:00"
DEFAULT_PARAMETERS = {"month": "2026-09", "channel": "online"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--month", default="2026-09")
    parser.add_argument("--channel", default="online", choices=["online", "store", "all"])
    args = parser.parse_args()
    contract, _ = read_frontmatter(ROOT / "bundle/computations/net-revenue.md")
    checks = []

    def check(condition, label):
        if not condition:
            raise AssertionError(label)
        checks.append(label)

    # Structural fixture checks; not a complete generic YAML or OKF validator.
    for path in sorted((ROOT / "bundle").rglob("*.md")):
        if path.name == "log.md":
            continue
        if path.name == "index.md" and path.parent != ROOT / "bundle":
            check(not path.read_text(encoding="utf-8").startswith("---"),
                  "index_has_no_frontmatter:" + str(path.relative_to(ROOT)))
            continue
        metadata, body = read_frontmatter(path)
        if path.name == "index.md":
            check(set(metadata) == {"okf_version"}, "root_index_version_only")
            continue
        check(bool(metadata.get("type")), "concept_type:" + str(path.relative_to(ROOT)))
        source_ids = {source.get("id") for source in metadata.get("sources", [])}
        labels = set(re.findall(r"\[\^([^\]]+)\]", body))
        check(labels <= source_ids, "footnotes_join_sources:" + path.name)
        check(all(source.get("resource") for source in metadata.get("sources", [])),
              "source_has_resource:" + path.name)

    receipt = execute(ROOT, DEFAULT_PARAMETERS)
    check(receipt["result"]["net_revenue_yuan"] == 280, "normal_280")
    normal = attest(ROOT, DEFAULT_PARAMETERS, receipt, 280)
    check(normal["passed"], "normal_attestation_passes")

    approved_source = (ROOT / "bundle/references/net_revenue.py").read_bytes()
    tampered_source = approved_source.replace(
        b'order["status"] == "paid"',
        b'order["status"] in ("paid", "cancelled")')
    check(tampered_source != approved_source, "attack_changes_computation")
    altered_receipt = execute(ROOT, DEFAULT_PARAMETERS, computation_override=tampered_source)
    altered = attest(ROOT, DEFAULT_PARAMETERS, altered_receipt,
                     altered_receipt["result"]["net_revenue_yuan"])
    check(altered_receipt["result"]["net_revenue_yuan"] == 330, "tampered_computation_330")
    check(not altered["passed"] and "executed_file_hash_mismatch" in altered["reasons"],
          "tampered_code_rejected")
    check("result_mismatch" in altered["reasons"], "tampered_result_rejected")

    wrong_display = attest(ROOT, DEFAULT_PARAMETERS, receipt, 300)
    check(wrong_display["reasons"] == ["displayed_value_mismatch"], "wrong_display_rejected")
    forged_receipt = copy.deepcopy(receipt)
    forged_receipt["result"]["net_revenue_yuan"] = 999
    forged = attest(ROOT, DEFAULT_PARAMETERS, forged_receipt, 999)
    check("receipt_differs_from_run_record" in forged["reasons"], "forged_receipt_rejected")
    wrong_parameters = attest(ROOT, {"month": "2026-09", "channel": "store"}, receipt, 280)
    check("parameters_mismatch" in wrong_parameters["reasons"], "wrong_parameters_rejected")

    unverified_meta = copy.deepcopy(contract)
    unverified_meta.pop("verified", None)
    human_meta = copy.deepcopy(contract)
    human_meta["verified"] = {"by": "human:fictional-reviewer",
                              "at": "2026-09-08T09:00:00+08:00"}
    old_meta = copy.deepcopy(human_meta)
    old_meta["verified"]["at"] = "2026-09-06T09:00:00+08:00"
    expired_meta = copy.deepcopy(contract)
    expired_meta["stale_after"] = NOW
    policies = {
        "unverified": consumption_policy(unverified_meta, NOW),
        "machine_reviewed": consumption_policy(contract, NOW),
        "human_reviewed_simulated": consumption_policy(human_meta, NOW),
        "expired_at_boundary": consumption_policy(expired_meta, NOW),
        "old_review": consumption_policy(old_meta, NOW),
    }
    check(policies["unverified"]["spec_trust_tier"] == "unverified", "unverified_tier")
    check(policies["unverified"]["readable_as_knowledge"], "unverified_still_readable")
    check(not policies["unverified"]["local_use_for_automatic_report"], "local_unverified_requires_review")
    check(policies["machine_reviewed"]["spec_trust_tier"] == "machine-confirmed", "machine_tier")
    check(policies["machine_reviewed"]["local_use_for_automatic_report"], "machine_current_usable")
    check(policies["human_reviewed_simulated"]["spec_trust_tier"] == "human-reviewed", "human_mapping_tier")
    check(trust_tier({"verified": [human_meta["verified"]]}) == "human-reviewed", "human_list_tier")
    check(policies["expired_at_boundary"]["spec_stale"], "stale_at_exact_instant")
    check(not consumption_policy(expired_meta, "2026-09-08T03:59:59Z")["spec_stale"],
          "not_stale_one_second_before")
    check(policies["old_review"]["spec_trust_tier"] == "human-reviewed", "old_review_does_not_rewrite_spec_tier")
    check(not policies["old_review"]["local_current_review"], "old_review_invalid_under_local_policy")
    check(normal["passed"] and not policies["expired_at_boundary"]["local_use_for_automatic_report"],
          "run_can_pass_while_definition_is_expired")
    try:
        aware_time("2026-09-08T12:00:00")
    except ValueError:
        checks.append("timezone_required")
    else:
        raise AssertionError("timezone required")
    try:
        validate_parameters(contract, dict(DEFAULT_PARAMETERS, algorithm="include_cancelled"))
    except ValueError:
        checks.append("algorithm_is_not_a_parameter")
    else:
        raise AssertionError("undeclared algorithm must fail")
    for parameters in ({"month": "2026-09", "channel": "store"},
                       {"month": "2026-08", "channel": "online"}):
        empty_receipt = execute(ROOT, parameters)
        check(empty_receipt["result"]["net_revenue_yuan"] == 0,
              "empty_scope_zero:" + json.dumps(parameters, sort_keys=True))
        check(attest(ROOT, parameters, empty_receipt, 0)["passed"], "empty_scope_attests")

    requested_parameters = {"month": args.month, "channel": args.channel}
    requested_receipt = execute(ROOT, requested_parameters)
    requested_verdict = attest(ROOT, requested_parameters, requested_receipt,
                               requested_receipt["result"]["net_revenue_yuan"])
    report = {
        "scenario": "fictional_teaching_example_not_business_data",
        "spec_commit": "ad30107c31c06aec8a7d5636e0d1058118604e6f",
        "executed_at": datetime.now(timezone.utc).isoformat(),
        "policy_evaluation_time": NOW,
        "requested_run": {"parameters": requested_parameters,
                          "result": requested_receipt["result"], "attestation": requested_verdict},
        "cases": {
            "normal": {"computed_value": 280, "displayed_value": 280, "attestation": normal,
                       "policy": policies["machine_reviewed"]},
            "tampered_computation": {"computed_value": 330, "displayed_value": 330,
                                     "attestation": altered},
            "tampered_display": {"computed_value": 280, "displayed_value": 300,
                                 "attestation": wrong_display},
            "tampered_receipt": {"attestation": forged},
            "wrong_parameters": {"attestation": wrong_parameters},
            "expired": {"attestation": normal, "policy": policies["expired_at_boundary"]},
            "old_review": {"attestation": normal, "policy": policies["old_review"]},
        },
        "trust_policy_cases": policies,
        "validation": {"all_passed": True, "check_count": len(checks), "checks": checks},
        "limitation": "The executor, local records, approval lock, and attester share one trust domain. "
                      "A party able to rewrite all of them can forge evidence; SHA alone proves neither "
                      "remote execution nor the truth of source data or policy."
    }
    for case in report["cases"].values():
        policy = case.get("policy", policies["machine_reviewed"])
        case["local_automatic_report_allowed"] = (
            case["attestation"]["passed"] and policy["local_use_for_automatic_report"])
    (ROOT / "demo-results.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n",
                                            encoding="utf-8")
    for label, artifact in (("normal-receipt", receipt), ("tampered-code-receipt", altered_receipt)):
        (ROOT / "runtime" / (label + ".json")).write_text(
            json.dumps(artifact, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
